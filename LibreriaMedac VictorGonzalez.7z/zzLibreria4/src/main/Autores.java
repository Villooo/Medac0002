package main;

public class Autores {

	String Nombre_Autores;

	public Autores(String nombre_Autores) {
		super();
		Nombre_Autores = nombre_Autores;
	}

	public String getNombre_Autores() {
		return Nombre_Autores;
	}

	public void setNombre_Autores(String nombre_Autores) {
		Nombre_Autores = nombre_Autores;
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
