package main;

import java.util.ArrayList;

import metodos.Metodo_Imprimir;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		String Autor1="Manolo Lama";
		String Autor2="Pedro Pircapiedra";
		
		String Título="Mas lento que el caballo del malo";
		String Precio="15€";
		String Editorial="La liga de la justicia";
		
		String Nombre_Proveedor_Libro1="Tu proveedor de confianza";
		String CIF_Proveedor_Libro1="12341234abcabc";
		String Teléfono_Proveedor_Libro1="+46000000001";
		String EditorialesDistribuidoras_Proveedor_Libro1="Casa Paco";
		
		
		Autores A1= new Autores(Autor1); 
		Autores A2= new Autores(Autor2); 
		
		ArrayList<Autores>ListaAutores=new ArrayList<>();
		ListaAutores.add(A1);
		ListaAutores.add(A2);
		
		
		
		
		Libros l1= new Libros(ListaAutores,Título,Precio,Editorial);
		Proveedores p1 = new Proveedores(Nombre_Proveedor_Libro1,CIF_Proveedor_Libro1
				,Teléfono_Proveedor_Libro1,EditorialesDistribuidoras_Proveedor_Libro1);
		
		Metodo_Imprimir.menuImprimir(l1, p1);
		
		
		
		
		
	}

}
