package main;

public class Proveedores {

	String Nombre_Proveedor;
	String CIF;
	String Teléfono;
	String EditorialesDistribuidoras;
	
	
	public Proveedores(String nombre_Proveedor, String cIF, String teléfono, String editorialesDistribuidoras) {
		super();
		Nombre_Proveedor = nombre_Proveedor;
		CIF = cIF;
		Teléfono = teléfono;
		EditorialesDistribuidoras = editorialesDistribuidoras;
	}


	public Proveedores() {
		super();
	}


	public String getNombre_Proveedor() {
		return Nombre_Proveedor;
	}


	public void setNombre_Proveedor(String nombre_Proveedor) {
		Nombre_Proveedor = nombre_Proveedor;
	}


	public String getCIF() {
		return CIF;
	}


	public void setCIF(String cIF) {
		CIF = cIF;
	}


	public String getTeléfono() {
		return Teléfono;
	}


	public void setTeléfono(String teléfono) {
		Teléfono = teléfono;
	}


	public String getEditorialesDistribuidoras() {
		return EditorialesDistribuidoras;
	}


	public void setEditorialesDistribuidoras(String editorialesDistribuidoras) {
		EditorialesDistribuidoras = editorialesDistribuidoras;
	} 
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
