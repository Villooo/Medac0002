package main;

import java.util.ArrayList;

public class Libros {

	private ArrayList<Autores> ListaAutores;
	private String Título;
	private String Precio;
	private String Editorial;
	
	
	public Libros(ArrayList<Autores> listaAutores, String título, String precio, String editorial) {
		super();
		ListaAutores = listaAutores;
		Título = título;
		Precio = precio;
		Editorial = editorial;
	}


	public Libros(String autor1, String autor2, String título1, String precioLibro1, String editorialLbro1) {
		super();
	}


	public ArrayList<Autores> getListaAutores() {
		return ListaAutores;
	}


	public void setListaAutores(ArrayList<Autores> listaAutores) {
		ListaAutores = listaAutores;
	}


	public String getTítulo() {
		return Título;
	}


	public void setTítulo(String título) {
		Título = título;
	}


	public String getPrecio() {
		return Precio;
	}


	public void setPrecio(String precio) {
		Precio = precio;
	}


	public String getEditorial() {
		return Editorial;
	}


	public void setEditorial(String editorial) {
		Editorial = editorial;
	}
	
	
	
	
}
