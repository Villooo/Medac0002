package metodos;

import main.Libros;
import main.Proveedores;

public class Metodo_Imprimir {

	public static void menuImprimir(Libros m1,Proveedores P1 ) {

		String S;
		
		S=String.format("---------------------------------------------------------------------\n"
				+ "Datos del Libro: \n\n"
				+ "Titulo del libro: %s\n"
				+ "Autores: %s y %s \n"
				+ "Precio: %s\n"
				+ "Editorial: %s\n\n"
				+ "Datos de los proveedores: \n"
				+ "Nombre del proveedor: %s \n"
				+ "CIF del proveedor: %s \n"
				+ "Telefono del proveedor: %s \n"
				+ "Editoriales Distribuidoras: %s \n"
				+ "---------------------------------------------------------------------",m1.getTítulo(),m1.getListaAutores().get(0).getNombre_Autores()
				,m1.getListaAutores().get(1).getNombre_Autores(),m1.getPrecio(),m1.getEditorial(),P1.getNombre_Proveedor()
				,P1.getCIF(),P1.getTeléfono(),P1.getEditorialesDistribuidoras());
		
		
		
		
		System.out.println(S);
		
		
		
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
